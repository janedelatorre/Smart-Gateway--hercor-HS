/**
 * =====================================================================
 * ENTRY LOGS MODULE - front-end logic
 * =====================================================================
 */
const API_LOGS = '../api/entry_logs.php';
let logsCurrentPage = 1;
let lastLogsData = [];

function loadLogs(page = 1) {
    logsCurrentPage = page;
    const params = new URLSearchParams({
        action: 'list',
        page: page,
        search: document.getElementById('searchLogs').value,
        date_from: document.getElementById('filterDateFrom').value,
        date_to: document.getElementById('filterDateTo').value,
        status: document.getElementById('filterStatusLog').value,
        method: document.getElementById('filterMethodLog').value,
        transaction_type: document.getElementById('filterTypeLog').value,
        grade: document.getElementById('filterGradeLog').value,
    });

    sgGet(`${API_LOGS}?${params.toString()}`).then(res => {
        if (!res.success) { sgToast('error', 'Failed to load entry logs'); return; }
        lastLogsData = res.data;
        renderLogsTable(res.data);
        renderLogsPagination(res.total, res.page, res.per_page);
        document.getElementById('logsSummary').textContent =
            `Showing ${res.data.length ? ((res.page - 1) * res.per_page + 1) : 0} to ${(res.page - 1) * res.per_page + res.data.length} of ${res.total} entries`;
    });
}

function renderLogsTable(logs) {
    const tbody = document.getElementById('logsTableBody');
    if (!logs.length) {
        tbody.innerHTML = `<tr><td colspan="9" class="text-center text-muted py-4">No entry logs found.</td></tr>`;
        return;
    }
    tbody.innerHTML = logs.map(l => {
        const dt = new Date(l.time_in.replace(' ', 'T'));
        return `<tr>
            <td>${dt.toLocaleDateString()}</td>
            <td>${dt.toLocaleTimeString()}</td>
            <td>${sgEscapeHtml(l.student_id ?? '-')}</td>
            <td>${sgEscapeHtml(l.fullname ?? 'Unknown')}</td>
            <td>${sgEscapeHtml(l.grade ?? '-')}</td>
            <td>${l.verification_method}</td>
            <td>${l.transaction_type ?? '-'}</td>
            <td>${l.status === 'Match' ? '<span class="badge-match">Match</span>' : `<span class="badge-denied">Denied</span>`}</td>
            <td>${sgEscapeHtml(l.verified_by ?? '-')}</td>
        </tr>`;
    }).join('');
}

function renderLogsPagination(total, page, perPage) {
    const totalPages = Math.max(1, Math.ceil(total / perPage));
    const ul = document.getElementById('logsPagination');
    if (!ul) return;

    const safePage = Math.min(Math.max(1, Number(page) || 1), totalPages);
    const previousDisabled = safePage <= 1;
    const nextDisabled = safePage >= totalPages;

    ul.innerHTML = `
        <li class="page-item${previousDisabled ? ' disabled' : ''}">
            <a class="page-link sg-pagination-arrow" href="#"
               aria-label="Previous page" title="Previous page"
               ${previousDisabled ? 'aria-disabled="true" tabindex="-1"' : `onclick="loadLogs(${safePage - 1}); return false;"`}>
                <i class="bi bi-chevron-left" aria-hidden="true"></i>
            </a>
        </li>
        <li class="page-item${nextDisabled ? ' disabled' : ''}">
            <a class="page-link sg-pagination-arrow" href="#"
               aria-label="Next page" title="Next page"
               ${nextDisabled ? 'aria-disabled="true" tabindex="-1"' : `onclick="loadLogs(${safePage + 1}); return false;"`}>
                <i class="bi bi-chevron-right" aria-hidden="true"></i>
            </a>
        </li>`;
}

['searchLogs', 'filterDateFrom', 'filterDateTo', 'filterStatusLog', 'filterMethodLog', 'filterTypeLog', 'filterGradeLog'].forEach(id => {
    document.getElementById(id).addEventListener('input', debounceLogs(() => loadLogs(1), 350));
    document.getElementById(id).addEventListener('change', () => loadLogs(1));
});
function debounceLogs(fn, delay) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), delay); }; }

// ---- Export helpers ----
function exportLogs(type) {
    if (!lastLogsData.length) { sgToast('info', 'No data to export.'); return; }
    if (type === 'excel') {
        let csv = 'Date,Time In,Student ID,Name,Grade,Method,Type,Status,Verified By\n';
        lastLogsData.forEach(l => {
            const dt = new Date(l.time_in.replace(' ', 'T'));
            csv += `${dt.toLocaleDateString()},${dt.toLocaleTimeString()},${l.student_id ?? ''},${l.fullname ?? ''},${l.grade ?? ''},${l.verification_method},${l.transaction_type ?? ''},${l.status},${l.verified_by ?? ''}\n`;
        });
        const blob = new Blob([csv], { type: 'text/csv' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'entry_logs.csv';
        link.click();
    }
}

document.addEventListener('DOMContentLoaded', () => loadLogs(1));
